# وهباني بلاس — Flutter starter v0.2

يحتوي هذا المشروع على واجهة عربية، شاشة دخول Firebase Authentication (رقم جوال + SMS، وبريد إلكتروني/كلمة مرور)، وشاشة رئيسية أساسية. المصادقة الحقيقية لا تعمل حتى تهيّئ مشروع Firebase وتولّد `firebase_options.dart`.

## متطلبات خارجية
- Flutter SDK.
- Firebase project ووسيلة دفع/خطة مناسبة عند الحاجة إلى SMS أو خدمات الإنتاج. تكلفة SMS تختلف حسب البلد والاستخدام.
- Android Studio/Android SDK لبناء Android.
- macOS مع Xcode لبناء iOS محلياً.
- حساب Apple Developer للنشر في App Store.
- حساب Google Play Console للنشر في Google Play.

## إعداد أول مرة
1. فك الضغط عن ZIP.
2. افتح مجلد المشروع في بيئة تطوير فيها Flutter.
3. ثبّت FlutterFire CLI واتبع دليل Firebase الرسمي، ثم نفّذ `flutterfire configure` من جذر المشروع. هذا ينشئ `lib/firebase_options.dart` وملفات إعداد المنصات.
4. في Firebase Console، فعّل Authentication > Sign-in method:
   - Phone
   - Email/Password
5. اضبط إعدادات SMS ومناطق الإرسال/التحقق حسب خيارات Firebase المتاحة لحسابك. أضف أرقام اختبار من Firebase Console للتجربة دون إرسال SMS مدفوعة.
6. فعّل Cloud Firestore وأنشئ قاعدة البيانات في المنطقة المناسبة.
7. انشر قواعد `firestore.rules` بعد مراجعتها واختبارها في Firebase Emulator Suite. القواعد بداية دفاعية وليست مراجعة أمنية نهائية.
8. شغّل `flutter pub get` ثم `flutter run`.

## بنية البيانات المقترحة
- `users/{uid}`: displayName, photoURL, createdAt, lastSeen
- `chats/{chatId}`: type, memberIds, createdAt, lastMessage, updatedAt
- `chats/{chatId}/messages/{messageId}`: senderId, text, createdAt, type, readBy

## نقاط أمان مهمة
- لا تضع مفاتيح خدمة Firebase Admin أو أسراراً في التطبيق.
- لا تستخدم قواعد Firestore مفتوحة للعامة.
- اختبر قواعد Firestore باستخدام Emulator Suite، خاصة منع المستخدم من قراءة محادثة ليس عضواً فيها.
- طبّق تحديد المعدل ومكافحة السبام، وحظر/إبلاغ المستخدمين، وسياسة احتفاظ وحذف الحساب والبيانات قبل الإطلاق.
- Firebase Authentication وHTTPS/TLS يحميان المصادقة والنقل، لكنهما لا يقدمان تلقائياً تشفيراً من طرف إلى طرف.
- واجهة الرسائل الحالية لا تزال نموذجاً؛ يلزم تنفيذ repository/service للمحادثات وربطها بـ Firestore والإشعارات قبل وصف الدردشة بأنها حقيقية.
- في iOS، يلزم ضبط APNs وPush Notifications إذا أضفت إشعارات فعلية، وكذلك إعدادات التحقق من رقم الهاتف المطلوبة من Firebase.
