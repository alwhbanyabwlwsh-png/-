import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

const brandPurple = Color(0xFF7C3AED);

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          CircleAvatar(backgroundColor: brandPurple, child: Icon(Icons.favorite_border)),
          SizedBox(width: 10),
          Text('وهباني بلاس'),
        ]),
        actions: [
          IconButton(
            tooltip: 'تسجيل الخروج',
            onPressed: () async => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF32165C), Color(0xFF151A2B)]),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0xFF4B2B78)),
            ),
            child: Text(
              'أهلاً بك في وهباني بلاس 💜\\n\\n'
              'تم تسجيل الدخول إلى الحساب: ${user?.phoneNumber ?? user?.email ?? user?.uid ?? "مستخدم"}\\n\\n'
              'الخطوة التالية: إنشاء المحادثات وحفظ الرسائل في Cloud Firestore.',
              style: const TextStyle(fontSize: 16, height: 1.7),
            ),
          ),
          const SizedBox(height: 18),
          const ListTile(leading: Icon(Icons.chat_bubble_outline), title: Text('المحادثات'), subtitle: Text('سيتم ربط الرسائل الحقيقية بعد إعداد قواعد قاعدة البيانات.')),
          const ListTile(leading: Icon(Icons.groups_outlined), title: Text('المجموعات'), subtitle: Text('قيد التطوير')),
          const ListTile(leading: Icon(Icons.security_outlined), title: Text('الأمان'), subtitle: Text('استخدم قواعد الوصول المرفقة ولا تفتح قاعدة البيانات للعامة.')),
        ],
      ),
    );
  }
}
