import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _auth = FirebaseAuth.instance;
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _phone = TextEditingController();
  final _smsCode = TextEditingController();
  bool _busy = false;
  bool _register = false;
  bool _usePhone = true;
  String? _verificationId;
  int? _resendToken;
  String? _notice;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _phone.dispose();
    _smsCode.dispose();
    super.dispose();
  }

  Future<void> _runEmailAuth() async {
    setState(() { _busy = true; _notice = null; });
    try {
      final email = _email.text.trim();
      final password = _password.text;
      if (email.isEmpty || password.length < 6) {
        throw FirebaseAuthException(
          code: 'invalid-input',
          message: 'أدخل البريد الإلكتروني وكلمة مرور من ٦ أحرف على الأقل.',
        );
      }
      if (_register) {
        await _auth.createUserWithEmailAndPassword(email: email, password: password);
      } else {
        await _auth.signInWithEmailAndPassword(email: email, password: password);
      }
    } on FirebaseAuthException catch (e) {
      setState(() => _notice = _friendlyError(e));
    } catch (_) {
      setState(() => _notice = 'تعذر إكمال العملية. تحقق من الاتصال والإعدادات.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendSms() async {
    final phone = _phone.text.trim();
    if (phone.isEmpty || !phone.startsWith('+')) {
      setState(() => _notice = 'أدخل رقم الجوال بصيغة دولية، مثل +9665xxxxxxxx.');
      return;
    }
    setState(() { _busy = true; _notice = null; });
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phone,
        forceResendingToken: _resendToken,
        verificationCompleted: (credential) async {
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (e) {
          if (mounted) setState(() => _notice = _friendlyError(e));
        },
        codeSent: (verificationId, resendToken) {
          if (!mounted) return;
          setState(() {
            _verificationId = verificationId;
            _resendToken = resendToken;
            _notice = 'تم إرسال رمز التحقق إذا كان الرقم صالحاً. أدخل الرمز أدناه.';
          });
        },
        codeAutoRetrievalTimeout: (verificationId) {
          _verificationId = verificationId;
        },
      );
    } on FirebaseAuthException catch (e) {
      setState(() => _notice = _friendlyError(e));
    } catch (_) {
      setState(() => _notice = 'تعذر إرسال الرمز. تحقق من إعداد Firebase والاتصال.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verifySms() async {
    final id = _verificationId;
    final code = _smsCode.text.trim();
    if (id == null || code.isEmpty) {
      setState(() => _notice = 'اطلب رمز التحقق أولاً ثم أدخله.');
      return;
    }
    setState(() { _busy = true; _notice = null; });
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: id,
        smsCode: code,
      );
      await _auth.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      setState(() => _notice = _friendlyError(e));
    } catch (_) {
      setState(() => _notice = 'تعذر التحقق من الرمز.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email': return 'صيغة البريد الإلكتروني غير صحيحة.';
      case 'user-not-found': return 'لا يوجد حساب بهذا البريد.';
      case 'wrong-password':
      case 'invalid-credential': return 'بيانات الدخول غير صحيحة.';
      case 'email-already-in-use': return 'هذا البريد مسجل مسبقاً.';
      case 'weak-password': return 'اختر كلمة مرور أقوى.';
      case 'invalid-phone-number': return 'رقم الجوال غير صحيح.';
      case 'invalid-verification-code': return 'رمز التحقق غير صحيح.';
      case 'too-many-requests': return 'محاولات كثيرة. حاول لاحقاً.';
      default: return e.message ?? 'حدث خطأ أثناء المصادقة (${e.code}).';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const CircleAvatar(
                    radius: 34,
                    backgroundColor: Color(0xFF7C3AED),
                    child: Icon(Icons.favorite_border, size: 35),
                  ),
                  const SizedBox(height: 14),
                  const Text('وهباني بلاس',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('تواصل أسهل.. أقرب إلى قلبك',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 28),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: true, label: Text('رقم الجوال'), icon: Icon(Icons.phone_android)),
                      ButtonSegment(value: false, label: Text('البريد الإلكتروني'), icon: Icon(Icons.email_outlined)),
                    ],
                    selected: {_usePhone},
                    onSelectionChanged: (v) => setState(() {
                      _usePhone = v.first;
                      _notice = null;
                    }),
                  ),
                  const SizedBox(height: 18),
                  if (_usePhone) ...[
                    TextField(
                      controller: _phone,
                      keyboardType: TextInputType.phone,
                      textDirection: TextDirection.ltr,
                      decoration: const InputDecoration(
                        labelText: 'رقم الجوال',
                        hintText: '+9665xxxxxxxx',
                        prefixIcon: Icon(Icons.phone),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_verificationId != null)
                      TextField(
                        controller: _smsCode,
                        keyboardType: TextInputType.number,
                        textDirection: TextDirection.ltr,
                        decoration: const InputDecoration(
                          labelText: 'رمز التحقق SMS',
                          prefixIcon: Icon(Icons.sms_outlined),
                        ),
                      ),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _busy ? null : (_verificationId == null ? _sendSms : _verifySms),
                      child: Text(_busy ? 'يرجى الانتظار...' :
                        (_verificationId == null ? 'إرسال رمز التحقق' : 'تأكيد الرمز وتسجيل الدخول')),
                    ),
                    if (_verificationId != null)
                      TextButton(
                        onPressed: _busy ? null : _sendSms,
                        child: const Text('إعادة إرسال الرمز'),
                      ),
                  ] else ...[
                    TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      textDirection: TextDirection.ltr,
                      decoration: const InputDecoration(
                        labelText: 'البريد الإلكتروني',
                        prefixIcon: Icon(Icons.email_outlined),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _password,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'كلمة المرور (٦ أحرف على الأقل)',
                        prefixIcon: Icon(Icons.lock_outline),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _busy ? null : _runEmailAuth,
                      child: Text(_busy ? 'يرجى الانتظار...' :
                        (_register ? 'إنشاء حساب بالبريد' : 'تسجيل الدخول بالبريد')),
                    ),
                    TextButton(
                      onPressed: () => setState(() {
                        _register = !_register;
                        _notice = null;
                      }),
                      child: Text(_register ? 'لديك حساب؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حساباً'),
                    ),
                    TextButton(
                      onPressed: _busy ? null : _resetPassword,
                      child: const Text('نسيت كلمة المرور؟'),
                    ),
                  ],
                  if (_notice != null) ...[
                    const SizedBox(height: 12),
                    Text(_notice!, textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFFC4B5FD), height: 1.5)),
                  ],
                  const SizedBox(height: 20),
                  const Text(
                    'بتسجيل الدخول، أنت توافق على شروط الاستخدام وسياسة الخصوصية. '
                    'هذه النسخة تحتاج إعداد Firebase قبل تشغيل المصادقة.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 11, color: Colors.white54, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _resetPassword() async {
    final email = _email.text.trim();
    if (email.isEmpty) {
      setState(() => _notice = 'أدخل بريدك الإلكتروني أولاً لاستعادة كلمة المرور.');
      return;
    }
    setState(() { _busy = true; _notice = null; });
    try {
      await _auth.sendPasswordResetEmail(email: email);
      setState(() => _notice = 'إذا كان البريد مسجلاً، فستصلك رسالة استعادة كلمة المرور.');
    } on FirebaseAuthException catch (e) {
      setState(() => _notice = _friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}
